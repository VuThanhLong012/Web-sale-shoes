package entity;

public class Order {
    private int id;
    private String name;
    private String image;
    private double price;
    private String title;
    private String description;
    private String namecustomer;
    private String phone;
    private String address;

    public int getId() {
        return id;
    }
    public Order(int id, String name, String image, double price, String title, String description,
            String namecustomer, String phone, String address) {
        this.id = id;
        this.name = name;
        this.image = image;
        this.price = price;
        this.title = title;
        this.description = description;
        this.namecustomer = namecustomer;
        this.phone = phone;
        this.address = address;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getImage() {
        return image;
    }
    public void setImage(String image) {
        this.image = image;
    }
    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getNamecustomer() {
        return namecustomer;
    }
    public void setNamecustomer(String namecustomer) {
        this.namecustomer = namecustomer;
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    @Override
    public String toString() {
        return "Order{" + "id=" + id + ", name=" + name + ", image=" + image + ", price=" + price + ", title=" + title + ", description=" + description + ", namecustomer=" + namecustomer + ", phone=" + phone + ", address=" + address + '}';
    }
}
